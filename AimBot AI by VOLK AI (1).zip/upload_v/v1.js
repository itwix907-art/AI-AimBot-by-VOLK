const versionsData = [
    {
        name: "AI-Aimbot Main Version",
        type: "Gaming AI Core",
        size: "23 MB",
        language: "Python",
        // هذا الرابط سيبقى كما هو، لكن سنغير طريقة التعامل معه في index.html
        link: "https://www.mediafire.com/file/s9jz8yogmvo6t7k/AI-Aimbot-main.zip/file",
        status: "Stable / Open Source"
    }
];
export default versionsData; 
